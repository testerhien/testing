package testing;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.core.annotations.findby.By;

public class addnewcustomerresult {
	public static WebDriver driver;
	public static String customerid;
	public static String accountid;
	public void LaunchBrowser(){ 
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\ACER\\Downloads\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demo.guru99.com/v4/");
		 } 
	@Given("^Login guru99 bank successfully$")
	 public void login_guru99_bank_successfully() throws Throwable {
		LaunchBrowser();
		WebElement username =  driver.findElement(By.name("uid"));
		WebElement password= driver.findElement(By.name("password"));
		WebElement login= driver.findElement(By.name("btnLogin"));
		username.sendKeys("mngr444374");
		password.sendKeys("aqagUte");
		login.click();
		String actualUrl="https://demo.guru99.com/v4/manager/Managerhomepage.php";
		String expectedUrl= driver.getCurrentUrl();
		Assert.assertEquals(expectedUrl,actualUrl);
	    //driver.quit();
		System.out.println("Login guru99 bank successfully");
	 }
	@When("^Add new customer$")
	 public void add_new_customer() throws Throwable {
		 driver.findElement(By.linkText("New Customer")).click();
		 Thread.sleep(5000);
         WebElement frame1 = driver.findElement(By.id("google_ads_iframe_/24132379/INTERSTITIAL_DemoGuru99_0"));
         driver.switchTo().frame(frame1);
         WebElement frame2 = driver.findElement(By.id("ad_iframe"));
         driver.switchTo().frame(frame2);
         driver.findElement(By.xpath("//div[@id='dismiss-button']/div/span")).click();
         driver.switchTo().defaultContent();
		 //driver.findElement(By.xpath("/html/body/div[3]/div/ul/li[2]/a")).click();
		 WebElement cusName =  driver.findElement(By.name("name"));
		 WebElement gender= driver.findElement(By.name("rad1"));
		 WebElement radio_male = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[5]/td[2]/input[1]"));
		 WebElement radio_female = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[5]/td[2]/input[2]"));
		 WebElement dob= driver.findElement(By.name("dob"));
		 WebElement address= driver.findElement(By.name("addr"));
		 WebElement city= driver.findElement(By.name("city"));
		 WebElement state= driver.findElement(By.name("state"));
		 WebElement pinno = driver.findElement(By.name("pinno"));
		 WebElement telephoneno = driver.findElement(By.name("telephoneno"));
		 WebElement email= driver.findElement(By.name("emailid"));
		 WebElement password= driver.findElement(By.name("password"));
		 WebElement submit= driver.findElement(By.name("sub"));
		 cusName.sendKeys("testerhien");
		 radio_female.click();
		 dob.sendKeys("09251995");
		 address.sendKeys("Pham Van Dong Street");
		 city.sendKeys("Thu Duc");
		 state.sendKeys("Ho Chi Minh");
		 pinno.sendKeys("123456");
		 telephoneno.sendKeys("0981234567");
		 email.sendKeys("testerhien2015@gmail.com");
		 password.sendKeys("654321");
		 submit.click();
		 System.out.println("Add new customer completely");
	 }
	 @Then("^Verify new customer be created$")
	 public void Verify_new_customer_be_created() throws Throwable {
		 WebElement message = driver.findElement(By.xpath("//*[@id=\"customer\"]/tbody/tr[1]/td/p"));
		 String actualResult="Customer Registered Successfully!!!";
		 String expectedResult= message.getText();
		 Assert.assertEquals(expectedResult,actualResult);
		 System.out.println("Verify new customer be created successfully");
		 WebElement cusIdElement = driver.findElement(By.xpath("//*[@id=\"customer\"]/tbody/tr[4]/td[2]"));
		 customerid = cusIdElement.getText();
	 }
	 @And("^Verify to create new account$")
	 public void Verify_to_create_new_account() throws Throwable {
		 driver.findElement(By.linkText("New Account")).click();
		 WebElement cusid = driver.findElement(By.name("cusid"));
		 WebElement inideposit = driver.findElement(By.name("inideposit"));
		 WebElement submit= driver.findElement(By.name("button2"));
		 cusid.sendKeys(customerid);
		 inideposit.sendKeys("100000");
		 submit.click();
		 WebElement message = driver.findElement(By.xpath("//*[@id=\"account\"]/tbody/tr[1]/td/p"));
		 String actualResult="Account Generated Successfully!!!";
		 String expectedResult= message.getText();
		 Assert.assertEquals(expectedResult,actualResult);
		 System.out.println("Verify new account be created successfully");
		 WebElement accIdElement = driver.findElement(By.xpath("//*[@id=\"account\"]/tbody/tr[4]/td[2]"));
		 accountid = accIdElement.getText();
	 }
	 @And("^Verify deposit function work fine$")
	 public void Verify_deposit_function_work_fine() throws Throwable {
		 driver.findElement(By.linkText("Deposit")).click();
		 WebElement accid = driver.findElement(By.name("accountno"));
		 WebElement amount = driver.findElement(By.name("ammount"));
		 WebElement description= driver.findElement(By.name("desc"));
		 WebElement submit= driver.findElement(By.name("AccSubmit"));
		 accid.sendKeys(accountid);
		 amount.sendKeys("100000");
		 description.sendKeys("testing");
		 submit.click();
	 }
}
